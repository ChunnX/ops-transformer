# Moe EP Exception Dump 功能验证报告

## 概述

对 PR #10465（feat: add Moe EP exception dump support）的 4 个算子进行异常 dump 功能验证：
- `MoeEpDispatch`
- `MoeEpDispatchEpilogue`
- `MoeEpCombine`
- `MoeEpCombineEpilogue`

## Trap 注入方式

在每个算子的 kernel cpp 中 `Process()` 之后插入 `MoeEpExceptionDump::DebugTrap()`，触发向地址 0x1 的非法写访问，产生 aicore error 507035，触发异常 dump 回调。

```cpp
op.Process();
MoeEpExceptionDump::DebugTrap(); // 临时维测：验证 dump 落盘后回退
```

## 测试环境

- **SoC**: ascend950
- **EP World Size**: 2
- **测试参数**: nmt=16, topK=2, hidden=1024, numExperts=4
- **测试框架**: `moe_train_test.py`（dispatch/combine/continue 三模式）
- **NPU 资源**: 通过 `qrun` 排队

## 验证流程

### 阶段 1：dispatch / combine（trap 全开）

当前 trap 提交已在 4 个 kernel 中全部注入，dispatch 和 combine 的主算子先于 epilogue 触发崩溃，可直接验证。

| 步骤 | 操作 |
|---|---|
| 编译全部 4 op | `bash build.sh --pkg --soc=ascend950 --ops=moe_ep_dispatch,moe_ep_dispatch_epilogue,moe_ep_combine,moe_ep_combine_epilogue` |
| 安装 | 安装到 `cann-9.2.0/vendors/custom_transformer` |
| 跑 dispatch | `is_dispatch=1` → dispatch Process() 后 trap → 507035 |
| 跑 combine | `is_combine=1` → combine Process() 后 trap → 507035 |
| 收集 dump | 两卡各 6 个 region bin 落盘 |
| 分析 | `dump_analysis_moe_ep.py` 生成 Excel 报告 |

### 阶段 2：dispatch_epilogue / combine_epilogue（屏蔽主算子 trap）

epilogue 由 `ElasticBuffer.dispatch()`/`ElasticBuffer.combine()` 内部自动调用。为验证 epilogue 的 dump，需临时注释主算子的 trap，使主算子正常执行，epilogue 触发崩溃。

| 步骤 | 操作 |
|---|---|
| 注释 dispatch trap | `sed -i 's/...DebugTrap().../...// DebugTrap().../'` |
| 注释 combine trap | 同上 |
| 重编重装 | 同上 |
| 跑 dispatch | dispatch 正常 → dispatch_epilogue trap → 507035 |
| 跑 combine | combine 正常 → combine_epilogue trap → 507035 |
| 恢复 trap | 4 个 trap 恢复全开 |

## 验证结果

### 落盘情况

| 算子 | 两卡 6 bin | metadata | per_core_diag | region 数据 |
|---|---|---|---|---|
| MoeEpDispatch | ✅ | ver=1, nmt=16, topK=2, epw=2, aiv=56 | 56 核 opCnt=1, runPos=3(URMA_DONE) | expert_count 有真实数据 |
| MoeEpCombine | ✅ | 同上 | 56 核 opCnt=1, runPos=2(URMA_DONE) | 全 0（dispatch 未参与） |
| MoeEpDispatchEpilogue | ✅ | 同上 | 56 核 opCnt=1, runPos=3(OUTPUT_DONE) | 同 dispatch |
| MoeEpCombineEpilogue | ✅ | 同上 | 56 核 opCnt=1, runPos=3(OUTPUT_DONE) | 全 0 |

### metadata 字段验证

```
layoutVersion=1, nmt=16, topK=2, hidden=1024, epWorldSize=2,
localExpertNum=2, aivNum=56, networkMode=0(direct), serverNum=1, rankNumPerServer=2
```

### context 验证

```
epRankId=0/1, rankSizePerServer=2, channelsPerRank=36
```

## 验收结论

**dump 功能正常。** 4 个算子在 aicore error 507035 触发时均能正确完成：
1. metadata 写入 window 前缀区
2. per_core_diag 记录（opCnt、runPosition、epRankId、aivId）
3. 6 个 region 数据落盘
4. host 侧回调正确解析并保存为 `.bin` 文件
5. 分析脚本生成 Excel 报告

## 附：分析脚本已知问题（未修复）

`dump_analysis_moe_ep.py` 的 per_core_diag 解析存在 2 个 bug，不影响 dump 数据正确性：

1. **run_pos 读错偏移**：脚本按 `[uint32 op_count, uint32 run_pos]` 读取，但实际 `MoeEpCoreDiagRecord` 以 `uint64 opCnt` 开头，脚本读到的 run_pos 实为 opCnt 的高 32 位（始终为 0）
2. **只读 op_index=0 的 record**：每 slot 512B 内含 4 个 op 的 record（offset 0/64/128/192），脚本只读 offset 0（dispatch 的），导致 combine/combine_epilogue 的 diag 显示为 0 核

## 产物目录

```
/home/l00946875/moe_ep_dump_verify/
├── VERIFICATION_REPORT.md          ← 本文件
├── dispatch/
│   ├── moe_ep_dump_analysis_result.xlsx
│   └── dump/                       ← 原始 dump 数据
├── combine/
│   ├── moe_ep_dump_analysis_result.xlsx
│   └── dump/
├── dispatch_epilogue/
│   ├── moe_ep_dump_analysis_result.xlsx
│   └── dump/
└── combine_epilogue/
    ├── moe_ep_dump_analysis_result.xlsx
    └── dump/
```