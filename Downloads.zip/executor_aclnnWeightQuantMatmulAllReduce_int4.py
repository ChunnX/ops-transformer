#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------------------------------------
# Copyright (c) 2025 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# -----------------------------------------------------------------------------------------------------------

import math
import os.path
import numpy as np
from itertools import product
import time
import torch
import torch.distributed as dist
from torch.distributed import ReduceOp
try:
   import torch_npu
except ImportError:
   pass

import ctypes
from atk.configs.dataset_config import InputDataset
from atk.tasks.api_execute import register
from atk.tasks.api_execute.base_api import BaseApi
from atk.tasks.api_execute.aclnn_base_api import AclnnBaseApi
from atk.tasks.backends.lib_interface.acl_wrapper import AclTensor
from atk.tasks.backends.lib_interface.acl_wrapper import AclIntArray
from atk.tasks.backends.lib_interface.acl_wrapper import AclTensorStruct
from atk.tasks.backends.lib_interface.acl_wrapper import nnopbase, AclFormat

@register("execute_aclnnWeightQuantMatmulAllReduce")
class DistFunctionApi(BaseApi):
    def __init__(self, task_result):
        super(DistFunctionApi, self).__init__(task_result)
        self.dist_task_info = task_result.dist_task_info

    def __call__(self, input_data: InputDataset, with_output: bool = False):
        self.init_by_input_data(input_data)
        input_chunk = input_data.kwargs['x1']
        weight_chunk = input_data.kwargs['x2']
        antiquant_scale_chunk = input_data.kwargs['antiquantScale']
        antiquantGroupSize = input_data.kwargs['antiquantGroupSize']
        dtype = input_chunk.dtype
        x3_chunk = input_data.kwargs['x3'] if self.is_x3 else None
        bias_chunk = input_data.kwargs['bias'] if self.is_bias else None
        antiquant_offset_chunk = input_data.kwargs['antiquantOffset'] if self.is_antiquant_offset else None

        if len(input_chunk.shape)==3:
            input_golden = input_chunk.reshape(-1, input_chunk.shape[-1])
        else:
            input_golden = input_chunk

        if self.name == "cpu" or (input_chunk.shape[-1] == 0 and self.dist_task_info.is_bm):
            input_chunk = input_chunk.to(torch.float32).cpu()
            weight_chunk = weight_chunk.to(torch.float32).cpu().contiguous()
            antiquant_scale = antiquant_scale_chunk.cpu().to(torch.float32)

            if antiquantGroupSize != 0:  # per-group场景
                for i in range(input_chunk.shape[-1]):
                    group_size_dim = i // antiquantGroupSize
                    if self.is_antiquant_offset:
                        antiquant_offset = antiquant_offset_chunk.cpu().to(torch.float32)
                        weight_chunk[i, :] = (weight_chunk[i, :] + antiquant_offset[group_size_dim, :]) * antiquant_scale[group_size_dim, :]
                    else:
                        weight_chunk[i, :] = weight_chunk[i, :] * antiquant_scale[group_size_dim, :]
            else:  # per-tensor/per-channel场景
                if self.is_antiquant_offset:
                    antiquant_offset = antiquant_offset_chunk.cpu().to(torch.float32)
                    weight_chunk = torch.add(weight_chunk, antiquant_offset)
                weight_chunk = torch.mul(weight_chunk, antiquant_scale)
            output = torch.matmul(input_chunk, weight_chunk)
            if bias_chunk != None:
                bias_chunk = bias_chunk.cpu()
                output = torch.add(output, bias_chunk)
            if x3_chunk != None:
                x3_chunk = x3_chunk.to(torch.float32).cpu()
                output = torch.add(output, x3_chunk)
            if self.name != "cpu":
                output = output.npu() 
                dist.all_reduce(output, op=dist.ReduceOp.SUM)
                return output.to(dtype)
            # 通信部分
            dist.all_reduce(output, op=dist.ReduceOp.SUM)
            return output
        if self.dist_task_info.is_bm:
            if bias_chunk != None and bias_chunk.dtype == torch.bfloat16:
                bias_chunk = bias_chunk.to(torch.float32)
            output = torch_npu.npu_weight_quant_batchmatmul(x=input_golden, weight=weight_chunk, bias=bias_chunk,
                                                    antiquant_scale=antiquant_scale_chunk, antiquant_offset=antiquant_offset_chunk,
                                                    antiquant_group_size=antiquantGroupSize)
            if x3_chunk != None:
                output = output.reshape(x3_chunk.shape)
                output = torch.add(output, x3_chunk)
            dist.all_reduce(output, op=ReduceOp.SUM)
            return output
        else:
            if dist.is_available():
                from torch.distributed.distributed_c10d import _get_default_group
                default_pg = _get_default_group()
                if torch.__version__ > '2.0.1':
                    hcomm_info = default_pg._get_backend(torch.device("npu")).get_hccl_comm_name(self.rank_id)
                else:
                    hcomm_info = default_pg.get_hccl_comm_name(self.rank_id)
            output = torch_npu.npu_mm_all_reduce_base(x1=input_chunk,
                                                            x2=weight_chunk,
                                                            x3=x3_chunk,
                                                            bias=bias_chunk,
                                                            hcom=hcomm_info,
                                                            reduce_op="sum",
                                                            antiquant_scale=antiquant_scale_chunk,
                                                            antiquant_offset=antiquant_offset_chunk,
                                                            antiquant_group_size=antiquantGroupSize
                                                           )
            return output

    def init_by_input_data(self, input_data: InputDataset):
        print("QWEASD aaa", flush=True)
        # 同时用于aclnn和其他后端
        # # =======QWE======
        
        # row_values = torch.arange(7).repeat(1024 // 7 + 1)[:1024]  # shape: [1024]

        # # 扩展为 [1024, 32]，每行数据相同
        # # result = row_values.unsqueeze(1).repeat(1, 32)
        # result = (torch.arange(64) % 7).repeat(1024, 1)

        # matrix = result.to(torch.int8).contiguous().to(input_data.kwargs['x2'].device)
        # input_data.kwargs['x2'] = matrix
        # # input_data.kwargs['antiquantScale'][512:] = 0
        # # =======QWE======
        self.rank_id = self.dist_task_info.rank
        world_size = self.dist_task_info.world_size
        input_chunk = input_data.kwargs['x1']
        weight_chunk = input_data.kwargs['x2']

        if input_chunk.shape == torch.Size([]):
            if self.name == "cpu" or self.dist_task_info.is_bm :
                return torch.tensor([])

        if input_chunk.shape != torch.Size([]):
            m_size = input_chunk.shape[0] // 8
            if m_size != 0:
                start = self.rank_id * m_size
                end = start + m_size
                input_chunk = input_chunk[start:end,:]

        if input_chunk.shape == torch.Size([2147483647,1]):
            if self.name == "cpu" or self.dist_task_info.is_bm :
                return torch.zeros(input_chunk.shape,dtype=input_chunk.dtype)

        CASES = list(product((False, True), repeat=4))
        optional_input = input_data.kwargs['optional_input']
        is_transpose = input_data.kwargs['isTranspose']

        self.is_antiquant_offset, self.is_bias, self.is_x3 , is_nz = CASES[optional_input]

        antiquant_scale_chunk = input_data.kwargs['antiquantScale']
        antiquantGroupSize = input_data.kwargs['antiquantGroupSize']

        if is_nz and self.name != "cpu"  and antiquantGroupSize == 0 and antiquant_scale_chunk.shape != torch.Size([1]):
            weight_chunk = torch_npu.npu_format_cast(weight_chunk, 29).contiguous()

        if is_transpose:
            weight_chunk = weight_chunk.transpose(0, 1)

        antiquant_offset_chunk = input_data.kwargs['antiquantOffset'] if self.is_antiquant_offset else None

        if antiquant_scale_chunk.shape[-1] != weight_chunk.shape[-1] and antiquant_scale_chunk.shape != torch.Size([1]):
            antiquant_scale_chunk = antiquant_scale_chunk.transpose(0, 1)
            if self.is_antiquant_offset:
                antiquant_offset_chunk = antiquant_offset_chunk.transpose(0, 1)

        # if self.device == 'pyaclnn':
        #     weight_chunk = weight_chunk.contiguous()
        #     antiquant_scale_chunk = antiquant_scale_chunk.contiguous()
        #     antiquant_offset_chunk = antiquant_offset_chunk.contiguous() if self.is_antiquant_offset else None

        input_data.kwargs['x1'] = input_chunk
        input_data.kwargs['x2'] = weight_chunk
        input_data.kwargs['antiquantScale'] = antiquant_scale_chunk
        input_data.kwargs['antiquantGroupSize'] = antiquantGroupSize
        input_data.kwargs['antiquantOffset'] = antiquant_offset_chunk if self.is_antiquant_offset else None
        if self.device == 'pyaclnn' and dist.is_available():
            from torch.distributed.distributed_c10d import _get_default_group
            default_pg = _get_default_group()
            if torch.__version__ > '2.0.1':
                hcomm_info = default_pg._get_backend(torch.device("npu")).get_hccl_comm_name(self.rank_id)
            else:
                hcomm_info = default_pg.get_hccl_comm_name(self.rank_id)
            # print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
            input_data.kwargs['group'] = default_pg
        super().init_by_input_data(input_data)

@register("pyaclnn_aclnnWeightQuantMatmulAllReduce")
class AclnnMatmulAllReduceQuant(AclnnBaseApi):
    def __init__(self, task_result, backend):
        super(AclnnMatmulAllReduceQuant, self).__init__(task_result, backend)
        self.dist_task_info = task_result.dist_task_info
        self.rank = self.dist_task_info.rank

    def after_call(self, output_packages):
        # x2 = self.int4_acl_tensor_to_torch(self.x2)
        # print("QWE pytensor after call", self.x2.pytensor.stride(), flush=True)
        # print("QWE pytensor after call", self.x2.tensor, flush=True)
        # print("QWE after call", x2[0].tolist(), flush=True)
        output = []
        for output_pack in output_packages:
            output.append(self.acl_tensor_to_torch(output_pack))
        return output

    def init_by_input_data(self, input_data: InputDataset):
        rank_id = self.dist_task_info.rank
        self.group = input_data.kwargs['group']
        
        input_data.kwargs['group'] = self.group._get_backend(torch.device("npu")).get_hccl_comm_name(rank_id)
        optional_input = input_data.kwargs['optional_input']
        input_data.kwargs.pop('optional_input')
        input_data.kwargs.pop('isTranspose')

        CASES = list(product((False, True), repeat=4))
        is_antiquant_offset, is_bias, is_x3 , is_nz = CASES[optional_input]

        input_args, output_packages = super().init_by_input_data(input_data)
        print("QWE before ", input_data.kwargs['x2'].stride(), flush=True)
        print("QWE before ", input_data.kwargs['x2'][0].tolist(), flush=True)

        input_args[1] = nnopbase.create_int4_acl_tensor(input_data.kwargs['x2'], fmt=AclFormat.ACL_FORMAT_ND, storage_shape=None)
        # input_args[1] = nnopbase.create_int4_acl_tensor(input_data.kwargs['x2'], fmt=AclFormat.ACL_FORMAT_ND, storage_shape=(1024, 64))
        # self.x2 = input_args[1]
        # print("QWE before ", dir(input_args[1]), flush=True)
        # print("QWE before __class__.__name__", input_args[1].__class__.__name__, flush=True)
        if not is_bias:
            input_args[2] = self.get_null_tensor_ptr()
        
        if not is_antiquant_offset:
            input_args[4] = self.get_null_tensor_ptr()
        
        if not is_x3:
            input_args[5] = self.get_null_tensor_ptr()

        torch.npu.synchronize()
        print("QWE fin init", flush=True)
        return input_args, output_packages

    def get_null_tensor_ptr(self):
        AclTensorPtr = ctypes.POINTER(AclTensor)
        null_void_ptr = ctypes.c_void_p(None)
        null_tensor_ptr = ctypes.cast(null_void_ptr, AclTensorPtr)
        return null_tensor_ptr

    def __call__(self):
        self.backend.aclnn_x_get_workspace_size()
        self.backend.aclnn_x()