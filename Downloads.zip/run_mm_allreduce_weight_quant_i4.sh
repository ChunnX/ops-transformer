#!/bin/bash
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source ~/miniconda3/etc/profile.d/conda.sh
conda activate atk_py39

DIRNAME=aclnnWeightQuantMatmulAllReduce
JSONNAME=aclnnWeightQuantMatmulAllReduce_int4

rm -rf cpu_bm golden input 
# 使用-wl [case_id] 运行指定用例
atk node --backend dist --name cpu --devices 6 --dist_backend gloo --is_bm true --output_path cpu_bm \
task -c $DIRNAME/$JSONNAME.json -p $DIRNAME/executor_$JSONNAME.py \
--task accuracy --save_data output -mt 1 --save_data input -l error

mkdir -p input golden/cpu_benchmark
mv cpu_bm/atk_output/$JSONNAME*/input/* input/
mv cpu_bm/atk_output/$JSONNAME*/output/dist_cpu/* golden/cpu_benchmark/
rm -r cpu_bm

rm -rf npu_bm npu_benchmark

atk node --backend dist --name npu_bm --devices 6 --dist_backend hccl --is_bm true --output_path npu_bm \
task -c $DIRNAME/$JSONNAME.json -p $DIRNAME/executor_$JSONNAME.py \
--input_data ./input/$JSONNAME --task accuracy --save_data output -mt 1 -l error

mkdir -p npu_benchmark/dist_npu_bm
mv npu_bm/atk_output/$JSONNAME*/output/dist_npu_bm/* npu_benchmark/dist_npu_bm/
rm -r npu_bm

# find /home/tyf/tyf/tilingkey/atk/00MM_AR/golden -depth -type d -name "rank_0" -execdir mv {} rank_4 \;
# # 将 rank_1 改为 rank_3
# find /home/tyf/tyf/tilingkey/atk/00MM_AR/golden -depth -type d -name "rank_1" -execdir mv {} rank_5 \;

export ASCEND_SLOG_PRINT_TO_STDOUT=1
export ASCEND_GLOBAL_LOG_LEVEL=0
atk task -n nodes_allreduce_i4.yaml -bmo golden  -c $DIRNAME/$JSONNAME.json \
-p $DIRNAME/executor_$JSONNAME.py --input_data ./input/$JSONNAME -mt 1 -l error --save_data output &> $DIRNAME/i4.log

unset ASCEND_SLOG_PRINT_TO_STDOUT
unset ASCEND_GLOBAL_LOG_LEVEL

grep -oP "LaunchKernel: kernel info : device_id=[0-9]+, stream_id=[0-9]+, task_id=[0-9]+, kernelType=[0-9]+, kernel_name=\KMatmulAllReduce_[^,]+" $DIRNAME/i4.log | sort  | uniq &> aclnnWeightQuantMatmulAllReduce_i4.log

# atk task -n nodes_allreduce_i4.yaml -bmo golden  -c aclnnWeightQuantMatmulAllReduce/aclnnWeightQuantMatmulAllReduce_int4.json \
# -p aclnnWeightQuantMatmulAllReduce/executor_aclnnWeightQuantMatmulAllReduce_int4.py --input_data ./input/aclnnWeightQuantMatmulAllReduce_int4 -mt 1 -l error -wl [9] &> wq.log
