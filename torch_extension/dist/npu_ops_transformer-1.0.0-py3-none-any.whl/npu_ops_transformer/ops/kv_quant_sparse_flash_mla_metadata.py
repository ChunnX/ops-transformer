# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

import torch
import torchair
from torch.library import impl
from npu_ops_transformer.op_builder.builder import OpBuilder
from npu_ops_transformer.op_builder.builder import AS_LIBRARY
from typing import Optional
from torchair.ge._ge_graph import Tensor, TensorSpec, DataType


class KvQuantSparseFlashMlaMetadataOpBuilder(OpBuilder):
    def __init__(self):
        super(KvQuantSparseFlashMlaMetadataOpBuilder, self).__init__("npu_kv_quant_sparse_flash_mla_metadata")

    def sources(self):
        """Path to C++ source code."""
        return ['ops/csrc/kv_quant_sparse_flash_mla_metadata.cpp']

    def schema(self) -> str:
        """PyTorch operator signature."""
        return "npu_kv_quant_sparse_flash_mla_metadata(int num_heads_q, int num_heads_kv, int head_dim, "       \
               "int kv_quant_mode, *, Tensor? cu_seqlens_q=None, Tensor? cu_seqlens_ori_kv=None, "              \
               "Tensor? seqused_q=None, Tensor? seqused_ori_kv=None, int? batch_size=0, "                       \
               "int? max_seqlen_q=0, int? max_seqlen_kv=0, int? ori_topk=0, int? tile_size=0, "                 \
               "int? rope_head_dim=0, int? ori_mask_mode=0, str? layout_q='BSND', str? layout_kv='BSND', "      \
               "bool? has_ori_kv=True) -> Tensor"

    def register_meta(self):
        """
        Registers Meta implementation (Shape/Dtype inference).
        Essential for Autograd and FakeTensor support.
        """
        @torch.library.register_fake("npu_ops_transformer::" + self.name)
        def npu_kv_quant_sparse_flash_mla_metadata_meta(
            num_heads_q: int, num_heads_kv: int, head_dim: int, kv_quant_mode: int,
            cu_seqlens_q: Optional[Tensor] = None, cu_seqlens_ori_kv: Optional[Tensor] = None,
            seqused_q: Optional[Tensor] = None, seqused_ori_kv: Optional[Tensor] = None,
            batch_size: Optional[int] = None, max_seqlen_q: Optional[int] = None, max_seqlen_kv: Optional[int] = None,
            ori_topk: Optional[int] = None, tile_size: Optional[int] = None, rope_head_dim: Optional[int] = None,
            ori_mask_mode: Optional[int] = None, layout_q: Optional[str] = None, layout_kv: Optional[str] = None,
            has_ori_kv: Optional[bool] = None):
            return torch.empty((1024), dtype=torch.int32, device="meta")

# Instantiate the builder
kv_quant_sparse_flash_mla_metadata_op_builder = KvQuantSparseFlashMlaMetadataOpBuilder()
op_module = kv_quant_sparse_flash_mla_metadata_op_builder.load()

@impl(AS_LIBRARY, kv_quant_sparse_flash_mla_metadata_op_builder.name, "PrivateUse1")
def npu_kv_quant_sparse_flash_mla_metadata(
    num_heads_q: int, num_heads_kv: int, head_dim: int, kv_quant_mode: int,
    cu_seqlens_q: Optional[Tensor] = None, cu_seqlens_ori_kv: Optional[Tensor] = None,
    seqused_q: Optional[Tensor] = None, seqused_ori_kv: Optional[Tensor] = None,
    batch_size: Optional[int] = None, max_seqlen_q: Optional[int] = None, max_seqlen_kv: Optional[int] = None,
    ori_topk: Optional[int] = None, tile_size: Optional[int] = None, rope_head_dim: Optional[int] = None,
    ori_mask_mode: Optional[int] = None, layout_q: Optional[str] = None, layout_kv: Optional[str] = None,
    has_ori_kv: Optional[bool] = None):
    """
    Dispatcher implementation: NPU.
    'PrivateUse1' is dispatch key for custom NPU backends.
    """
    batch_size = 0 if batch_size is None else batch_size
    max_seqlen_q = 0 if max_seqlen_q is None else max_seqlen_q
    max_seqlen_kv = 0 if max_seqlen_kv is None else max_seqlen_kv
    ori_topk = 0 if ori_topk is None else ori_topk
    tile_size = 0 if tile_size is None else tile_size
    rope_head_dim = 0 if rope_head_dim is None else rope_head_dim
    ori_mask_mode = 0 if ori_mask_mode is None else ori_mask_mode
    layout_q = "BSND" if layout_q is None else layout_q
    layout_kv = "BSND" if layout_kv is None else layout_kv
    has_ori_kv = True if has_ori_kv is None else has_ori_kv
 
    return op_module.npu_kv_quant_sparse_flash_mla_metadata(
        num_heads_q, num_heads_kv, head_dim, kv_quant_mode, cu_seqlens_q, cu_seqlens_ori_kv, seqused_q, seqused_ori_kv,
        batch_size, max_seqlen_q, max_seqlen_kv, ori_topk, tile_size, rope_head_dim, ori_mask_mode, layout_q, layout_kv,
        has_ori_kv)

@torch.library.register_kernel("npu_ops_transformer::npu_kv_quant_sparse_flash_mla_metadata", None)
def npu_kv_quant_sparse_flash_mla_metadata_fallback(
    num_heads_q: int, num_heads_kv: int, head_dim: int, kv_quant_mode: int,
    cu_seqlens_q: Optional[Tensor] = None, cu_seqlens_ori_kv: Optional[Tensor] = None,
    seqused_q: Optional[Tensor] = None, seqused_ori_kv: Optional[Tensor] = None,
    batch_size: Optional[int] = None, max_seqlen_q: Optional[int] = None, max_seqlen_kv: Optional[int] = None,
    ori_topk: Optional[int] = None, tile_size: Optional[int] = None, rope_head_dim: Optional[int] = None,
    ori_mask_mode: Optional[int] = None, layout_q: Optional[str] = None, layout_kv: Optional[str] = None,
    has_ori_kv: Optional[bool] = None):
    # 处理所有 tensor 都为 None 的情况
    # 可以在这里创建一个 NPU tensor 来触发 PrivateUse1 backend
    if all(t is None for t in [cu_seqlens_q, cu_seqlens_ori_kv]):
             _ = torch.empty(1, dtype=torch.int32, device="npu")
    # 调用 NPU 实现
    return npu_kv_quant_sparse_flash_mla_metadata(
        num_heads_q, num_heads_kv, head_dim, kv_quant_mode, cu_seqlens_q, cu_seqlens_ori_kv, seqused_q, seqused_ori_kv,
        batch_size, max_seqlen_q, max_seqlen_kv, ori_topk, tile_size, rope_head_dim, ori_mask_mode, layout_q, layout_kv,
        has_ori_kv)
        
torch.compiler.allow_in_graph(npu_kv_quant_sparse_flash_mla_metadata)