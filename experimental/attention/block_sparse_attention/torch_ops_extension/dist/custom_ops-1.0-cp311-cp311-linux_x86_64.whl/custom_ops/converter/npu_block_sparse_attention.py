# This program is free software, you can redistribute it and/or modify.
# Copyright (c) 2025 Huawei Technologies Co., Ltd.
# This file is a part of the CANN Open Software.
# Licensed under CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

from typing import (
    Any, Callable, ContextManager, Iterator, List, Literal, NamedTuple, Optional, Sequence, Tuple, TypeVar,
    Union, overload,
)

import torch
import torchair
from torch import Generator, contiguous_format, inf, strided, SymInt
from torch.types import Device, Number, _bool, _complex, _device, _dtype, _float, _int, _layout, _qscheme, _size
from torchair._ge_concrete_graph import ge_apis as ge
from torchair._ge_concrete_graph.fx2ge_converter import declare_supported, register_fx_node_ge_converter
from torchair.ge._ge_graph import Tensor, TensorSpec, DataType
from torchair._ge_concrete_graph.supported_declaration import _TypedTensor, F32, F16, F64, I32, I16, I64, I8, U8, \
    BOOL, Support
from torchair.ge import attr


# 为自定义算子注册converter，用于torch.compile 场景成图
# 注意： meta_outputs形参名为固定写法，若写错会影响ge节点的输出dtype与shape推导
@register_fx_node_ge_converter(torch.ops.custom.npu_block_sparse_attention.default)
def convert_npu_block_sparse_attention(
    query: Tensor,
    key: Tensor,
    value: Tensor,
    q_scale: Tensor,
    k_scale: Tensor,
    v_scale: Tensor,
    p_scale: Tensor,
    sparse_indices: Tensor,
    sparse_seq_len: Tensor,
    atten_mask: Tensor,
    softmax_scale: float,
    q_block_size: int,
    kv_block_size: int,
    *,
    cu_seqlens_q: Optional[Tensor] = None,
    cu_seqlens_kv: Optional[Tensor] = None,
    seqused_q: Optional[Tensor] = None,
    seqused_kv: Optional[Tensor] = None,
    block_table: Optional[Tensor] = None,
    metadata: Optional[Tensor] = None,
    max_seqlen_q: int = 0,
    max_seqlen_kv: int = 0,
    kv_layout: str = "PA_BSND",
    sparse_indices_layout: str = "BNQQbKb",
    quant_mode: int = 0,
    mask_mode: int = 0,
    return_softmax_lse: bool = False,
    meta_outputs: List[TensorSpec] = None,
):
    return torchair.ge.custom_op(
        "BlockSparseAttention",
        inputs={"query": query,
                "key": key,
                "value": value,
                "q_scale": q_scale,
                "k_scale": k_scale,
                "v_scale": v_scale,
                "p_scale": p_scale,
                "cu_seqlens_q": cu_seqlens_q,
                "cu_seqlens_kv": cu_seqlens_kv,
                "seqused_q": seqused_q,
                "seqused_kv": seqused_kv,
                "sparse_indices": sparse_indices,
                "sparse_seq_len": sparse_seq_len,
                "block_table": block_table,
                "atten_mask": atten_mask,
                "metadata": metadata,
               },
        attrs={"max_seqlen_q": attr.Int(max_seqlen_q),
               "max_seqlen_kv": attr.Int(max_seqlen_kv),
               "softmax_scale": attr.Float(softmax_scale),
               "q_block_size": attr.Int(q_block_size),
               "kv_block_size": attr.Int(kv_block_size),
               "kv_layout": attr.Str(kv_layout),
               "sparse_indices_layout": attr.Str(sparse_indices_layout),
               "quant_mode": attr.Int(quant_mode),
               "mask_mode": attr.Int(mask_mode),
               "return_softmax_lse": attr.Bool(return_softmax_lse),
               },
        outputs=['attention_out', 'softmax_lse']
    )
